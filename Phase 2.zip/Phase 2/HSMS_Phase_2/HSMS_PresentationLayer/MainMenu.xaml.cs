﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HSMS_PresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window        
    {
        public static MainWindow AppWindow;

        public MainWindow()
        {
            InitializeComponent();
            AppWindow = this;
        }

        private void btnQuit_Click(object sender, RoutedEventArgs e)    //Button for exit operation
        {
            System.Windows.Application.Current.Shutdown();
        }

        private void btnSocietyMemberMenu_Click(object sender, RoutedEventArgs e)    //Society Member Menu instance will be created
        {
            Enter_Flat_No objUCAddFlatNo = new Enter_Flat_No();
            grdHSMS.Children.Add(objUCAddFlatNo);
            Grid.SetRow(objUCAddFlatNo, 0);
            Grid.SetColumn(objUCAddFlatNo, 0);
            grdMainMenu.Visibility = Visibility.Collapsed;
        }

        private void btnCommitteeMemberMenu_Click(object sender, RoutedEventArgs e)     //Menu for Committee Member will be shown
        {
            Society_Committee_Member_Menu society_Committee = new Society_Committee_Member_Menu();
            grdHSMS.Children.Add(society_Committee);
            Grid.SetRow(society_Committee, 0);
            Grid.SetColumn(society_Committee, 0);
            grdMainMenu.Visibility = Visibility.Collapsed;
        }

        public void showMenu()          //For showing the menu from outside function
        {
            grdMainMenu.Visibility = Visibility.Visible;
        }
    }
}
