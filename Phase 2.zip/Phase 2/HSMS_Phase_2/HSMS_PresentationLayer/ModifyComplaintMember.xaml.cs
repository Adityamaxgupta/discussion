﻿using Complaint_Entity;
using ComplaintCategory_Entity;
using ComplaintStatus_Entity;
using HSMS_BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HSMS_PresentationLayer
{
    /// <summary>
    /// Interaction logic for ModifyComplaintMember.xaml
    /// </summary>
    public partial class ModifyComplaintMember : UserControl
    {
        int Id;
        Complaint complaint;
        public ModifyComplaintMember()      //Initializing the page including the combobox
        {
            InitializeComponent();
            List<ComplaintStatus> statuses = HSMSBLL.GetStatusesBLL();
            foreach (var item in statuses)
            {
                cmbstatus.Items.Add(item.Description);
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)        //Return to the menu
        {
            Society_Committee_Member_Menu.menu.showSocietyCommmitteeMemberMenu();
            this.Visibility = Visibility.Collapsed;
        }

        private void Btnsearch_Click(object sender, RoutedEventArgs e)      //For searching the logic first
        {
            try
            {
                if (txtid.Text == "" || txtid.Text == null)
                {
                    MessageBox.Show("Please Enter ID");
                }
                else
                {
                    if (int.TryParse(txtid.Text, out int id))
                    {

                        complaint = HSMS_BLL.HSMSBLL.SearchComplaintMemberBLL(id);
                        Id = id;
                        txbblock.Text = complaint.Block;
                        txbcategory.Text = complaint.Category;
                        txbcomid.Text = complaint.ComplaintId.ToString();
                        txbdate.Text = complaint.Date.ToShortDateString();
                        txbdesc.Text = complaint.Description;
                        txbflatno.Text = complaint.FlatNo.ToString();
                        cmbstatus.Text = complaint.Status.ToString();
                        if (complaint.Note == null)
                        {
                            txtnote.Text = "";
                        }
                        else
                        {
                            txtnote.Text = complaint.Note;
                        }
                        grddetails.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        MessageBox.Show("Please Enter ID in valid format");
                    }
                }
                
            }
            catch (Exception)
            {
                grddetails.Visibility = Visibility.Hidden;
                MessageBox.Show("No Results for given ID");
            }
        }

        private void Btnmodify_Click(object sender, RoutedEventArgs e)      //Actual code for modification
        {
            if (grddetails.Visibility == Visibility.Visible)
            {
                try
                {
                    string note = "";
                    int i = 0;
                    foreach (var item in txtnote.Text.ToCharArray())
                    {
                        if (i < 50)
                        {
                            if (item.ToString() != "\n")
                            {
                                note = note + item.ToString();
                                i++;
                            }
                            else
                            {
                                note = note + item.ToString();
                                i = 0;
                            }
                        }
                        else
                        {
                            if (item.ToString() == "\n" || item.ToString() == " ")
                            {
                                note = note + "\n";
                                i = 0;
                            }
                            else
                            {
                                note = note + item.ToString();
                                i++;
                            }
                        }

                    }
                    complaint.Note = note;
                    complaint.Status = cmbstatus.Text;
                    if (HSMSBLL.ModifyComplaintMemberBLL(complaint))
                    {
                        MessageBox.Show("Successfully Updated");
                    }
                    else
                    {
                        MessageBox.Show("Could not perform the operation");
                    }
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Updation Failed\n" + ex.Message);
                }
                Society_Committee_Member_Menu.menu.showSocietyCommmitteeMemberMenu();
                this.Visibility = Visibility.Collapsed;
            }
            else
            {
                MessageBox.Show("Nothing To Modify");
            }
        }
    }
}