﻿using Complaint_Entity;
using HSMS_BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HSMS_PresentationLayer
{
    /// <summary>
    /// Interaction logic for ComplaintSummary.xaml
    /// </summary>
    public partial class ComplaintSummary : UserControl
    {
        public ComplaintSummary(int flat,string block)          //The whole summary will load after initializing the control
        {
            InitializeComponent();
            try
            {
                List<Complaint> complaintlist = HSMSBLL.ComplaintsSummaryBLL(flat,block);
                dgList.ItemsSource = complaintlist.Select(co => new { ID = co.ComplaintId, co.Category, co.Block, co.FlatNo, co.Description, Date = co.Date.ToLongDateString() }).ToList();
                if (complaintlist.Count == 0)
                {
                    MessageBox.Show("No Complaint To Show");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Society_Member_Menu.menu.showSocietyMemberMenu();
            this.Visibility = Visibility.Collapsed;
        }
    }
}
