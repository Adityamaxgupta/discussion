﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Complaint_Entity;

namespace HSMS_PresentationLayer
{
    /// <summary>
    /// Interaction logic for SearchComplaint.xaml
    /// </summary>
    public partial class SearchComplaint : UserControl
    {
        static string block;
        static int flat;
        public SearchComplaint(string b, int f)
        {
            block = b;
            flat = f;
            InitializeComponent();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)        //Going back to the previous menu
        {
            Society_Member_Menu.menu.showSocietyMemberMenu();
            this.Visibility = Visibility.Collapsed;
        }

        private void Btnsearch_Click(object sender, RoutedEventArgs e)      //Searching the complaint
        {
            try
            {
                if (txtid.Text == "" || txtid.Text == null)
                {
                    MessageBox.Show("Please Enter ID");
                }
                else
                {
                    if (int.TryParse(txtid.Text, out int id))
                    {
                        Complaint complaint = HSMS_BLL.HSMSBLL.SearchComplaintBLL(id,flat,block);
                        txbblock.Text = complaint.Block;
                        txbcategory.Text = complaint.Category;
                        txbcomid.Text = complaint.ComplaintId.ToString();
                        txbdate.Text = complaint.Date.ToShortDateString();
                        txbdesc.Text = complaint.Description;
                        txbflatno.Text = complaint.FlatNo.ToString();
                        txbstatus.Text = complaint.Status.ToString();
                        if (complaint.Note == "" || complaint.Note == null)
                        {
                            txbnote.Text = "No Notes Yet";
                        }
                        else
                        {
                            txbnote.Text = complaint.Note;
                        }
                        grddetails.Visibility = Visibility.Visible;
                    }
                    else    //If ID is in invalid format
                    {
                        MessageBox.Show("Please Enter ID in valid format");
                    }
                }
                
            }
            catch (Exception)   //If the ID is not there in the database
            {
                grddetails.Visibility = Visibility.Hidden;
                MessageBox.Show("No Results for given ID");
            }
        }
    }
}
