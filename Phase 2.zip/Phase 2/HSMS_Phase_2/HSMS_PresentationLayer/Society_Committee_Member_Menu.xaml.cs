﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HSMS_PresentationLayer
{
    /// <summary>
    /// Interaction logic for Society_Committee_Member_Menu.xaml
    /// </summary>
    public partial class Society_Committee_Member_Menu : UserControl
    {
        public static Society_Committee_Member_Menu menu;
        public Society_Committee_Member_Menu()
        {
            InitializeComponent();
            menu = this;
        }

        private void BtnSearchcommmem_Click(object sender, RoutedEventArgs e)   //Opening search window
        {
            this.Visibility = Visibility.Collapsed;
            SearchComplaintMember searched = new SearchComplaintMember();
            MainWindow.AppWindow.grdHSMS.Children.Add(searched);
            Grid.SetRow(searched, 0);
            Grid.SetColumn(searched, 0);
        }

        private void BtnModifycommmem_Click(object sender, RoutedEventArgs e)   //Opening modify window
        {
            this.Visibility = Visibility.Collapsed;
            ModifyComplaintMember obj = new ModifyComplaintMember();
            MainWindow.AppWindow.grdHSMS.Children.Add(obj);
            Grid.SetRow(obj, 0);
            Grid.SetColumn(obj, 0);
        }

        private void BtnRemovecommmem_Click(object sender, RoutedEventArgs e)   //Opening remove window
        {
            this.Visibility = Visibility.Collapsed;
            RemoveComplaintMember obj = new RemoveComplaintMember();
            MainWindow.AppWindow.grdHSMS.Children.Add(obj);
            Grid.SetRow(obj, 0);
            Grid.SetColumn(obj, 0);
        }

        private void BtnViewSummarycommmem_Click(object sender, RoutedEventArgs e)  //Opening view summary window
        {
            this.Visibility = Visibility.Collapsed;
            ComplaintSummaryMember summary = new ComplaintSummaryMember();
            MainWindow.AppWindow.grdHSMS.Children.Add(summary);
            Grid.SetRow(summary, 0);
            Grid.SetColumn(summary, 0);
        }

        private void BtnReturnToPreviouscommmem_Click(object sender, RoutedEventArgs e) //Back to the previous menu
        {
            this.Visibility = Visibility.Collapsed;
            MainWindow.AppWindow.showMenu();
        }

        private void BtnQuitcommmem_Click(object sender, RoutedEventArgs e)     //terminating the application
        {
            System.Windows.Application.Current.Shutdown();
        }

        public void showSocietyCommmitteeMemberMenu()       //Reloading the menu
        {
            this.Visibility = Visibility.Visible;
        }

    }
}
