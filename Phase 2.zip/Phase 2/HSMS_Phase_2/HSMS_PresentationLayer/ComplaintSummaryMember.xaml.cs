﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Complaint_Entity;
using ComplaintStatus_Entity;
using ComplaintCategory_Entity;
using HSMS_BLL;

namespace HSMS_PresentationLayer
{
    /// <summary>
    /// Interaction logic for ComplaintSummaryMember.xaml
    /// </summary>
    public partial class ComplaintSummaryMember : UserControl
    {
        public ComplaintSummaryMember()     //This is the initial loading. Here all the data will be loaded
        {
            InitializeComponent();
            List<Complaint> complaintlist=HSMSBLL.ComplaintsSummaryMemberBLL();
            dgList.ItemsSource = complaintlist.Select(co => new{ ID = co.ComplaintId, co.Category, co.Block, co.FlatNo, co.Description, Date=co.Date.ToLongDateString()}).ToList();
            if (complaintlist.Count == 0)
            {
                MessageBox.Show("No Complaint To Show");
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Society_Committee_Member_Menu.menu.showSocietyCommmitteeMemberMenu();
            this.Visibility = Visibility.Collapsed;
        }
    }
}
