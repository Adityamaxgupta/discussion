﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HSMS_PresentationLayer
{
    /// <summary>
    /// Interaction logic for Society_Member_Menu.xaml
    /// </summary>
    public partial class Society_Member_Menu : UserControl
    {
        public static Society_Member_Menu menu;
        private static int flatno = 0;
        private static string block = "";
        public Society_Member_Menu(int n,string b)      //Initializing the menu
        {
            flatno = n;
            block = b;
            InitializeComponent();
            menu = this;
            lblflatnblock.Content = "Block: " + block + "\tFlat No: " + n;
        }

        private void BtnCreate_Click(object sender, RoutedEventArgs e)      //Loading the create control
        {
            this.Visibility = Visibility.Collapsed;
            CreateComplaint objUCCreateComplaint = new CreateComplaint(flatno,block);
            MainWindow.AppWindow.grdHSMS.Children.Add(objUCCreateComplaint);
            Grid.SetRow(objUCCreateComplaint, 0);
            Grid.SetColumn(objUCCreateComplaint, 0);
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)      //Loading the search control
        {
            this.Visibility = Visibility.Collapsed;
            SearchComplaint searched = new SearchComplaint(block,flatno);
            MainWindow.AppWindow.grdHSMS.Children.Add(searched);
            Grid.SetRow(searched, 0);
            Grid.SetColumn(searched, 0);
        }

        private void BtnModify_Click(object sender, RoutedEventArgs e)      //Loading the modify control
        {
            this.Visibility = Visibility.Collapsed;
            ModifyComplaint obj = new ModifyComplaint(block, flatno);
            MainWindow.AppWindow.grdHSMS.Children.Add(obj);
            Grid.SetRow(obj, 0);
            Grid.SetColumn(obj, 0);
        }

        private void BtnRemove_Click(object sender, RoutedEventArgs e)      //Loading the remove control
        {
            this.Visibility = Visibility.Collapsed;
            RemoveComplaint obj = new RemoveComplaint(block,flatno);
            MainWindow.AppWindow.grdHSMS.Children.Add(obj);
            Grid.SetRow(obj, 0);
            Grid.SetColumn(obj, 0);
        }

        private void BtnViewSummary_Click(object sender, RoutedEventArgs e)     //Loading the summary table
        {
            this.Visibility = Visibility.Collapsed;
            ComplaintSummary summary = new ComplaintSummary(flatno,block);
            MainWindow.AppWindow.grdHSMS.Children.Add(summary);
            Grid.SetRow(summary, 0);
            Grid.SetColumn(summary, 0);
        }

        private void BtnReturnToPrevious_Click(object sender, RoutedEventArgs e)    //Returning to the previous menu
        {
            this.Visibility = Visibility.Collapsed;
            MainWindow.AppWindow.showMenu();
        }

        private void BtnQuit_Click(object sender, RoutedEventArgs e)        //Quiting the application
        {
            System.Windows.Application.Current.Shutdown();
        }
        public void showSocietyMemberMenu()     //Reloading the menu from other controls
        {
            this.Visibility = Visibility.Visible;
        }
    }
}
