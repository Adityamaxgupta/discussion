﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using ComplaintCategory_Entity;
using System.Windows.Controls;
using System.Windows.Data;
using HSMS_BLL;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Complaint_Entity;

namespace HSMS_PresentationLayer
{
    /// <summary>
    /// Interaction logic for CreateComplaint.xaml
    /// </summary>
    public partial class CreateComplaint : UserControl
    {
        bool selected = false;
        private static int flatno = 0;
        private static string block = "";
        public CreateComplaint(int n,string b)          //Loading the initial control
        {
            InitializeComponent();
            flatno = n;
            block = b;
            txtflatno.Text = n.ToString();
            txtblock.Text = b;
            List<ComplaintCategory> categeroies = HSMSBLL.GetCategoriesBLL();       //The List will be created from the database itself
            foreach (var item in categeroies)
            {
                cmbcategory.Items.Add(item.Description);
            }
        }

        private void BtnSubmit_Click(object sender, RoutedEventArgs e)      //Using the submit event, the complaint is created
        {
            try
            {
                string cat=null;
                if (selected)
                {
                    cat = cmbcategory.SelectedValue.ToString();
                }
                
                string desc="";
                int i = 0;
                foreach (var item in txtdesc.Text.ToCharArray())        //Logic for multilining very long description.
                {
                    if (i < 50)
                    {
                        if (item.ToString() != "\n")
                        {
                            desc = desc + item.ToString();
                            i++;
                        }
                        else
                        {
                            desc = desc + item.ToString();
                            i = 0;
                        }
                    }
                    else
                    {
                        if (item.ToString() == "\n" || item.ToString() == " ")
                        {
                            desc = desc + "\n";
                            i=0;
                        }
                        else
                        {
                            desc = desc + item.ToString();
                            i++;
                        }
                    }
                    
                }
                int id = -1;
                Complaint complaint = new Complaint(cat,block,flatno,desc,DateTime.Now);
                if(HSMSBLL.CreateComplaintBLL(complaint, out id))
                {
                    if (id > 0)
                    {
                        MessageBox.Show("Complaint Created Successfully\nComplaint ID=" + id);      //The user will be shown complaint id after the execution
                    }
                }
                else
                {
                    MessageBox.Show("Could not perform the operation");
                }
                
                Society_Member_Menu.menu.showSocietyMemberMenu();
                this.Visibility = Visibility.Collapsed;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Problem Encountered\n"+ex.Message);
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)      //The cancel button will cancel the operation taking back to the previous menu
        {
            Society_Member_Menu.menu.showSocietyMemberMenu();
            this.Visibility = Visibility.Collapsed;
        }

        private void Cmbcategory_SelectionChanged(object sender, SelectionChangedEventArgs e)       //This is a logic to check whether the user have atall selscted anything or not
        {
            selected = true;
        }
    }
}
