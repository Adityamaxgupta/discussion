﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Complaint_Entity;
using HSMS_BLL;

namespace HSMS_PresentationLayer
{
    /// <summary>
    /// Interaction logic for SearchComplaintMember.xaml
    /// </summary>
    public partial class SearchComplaintMember : UserControl
    {
        public SearchComplaintMember()
        {
            InitializeComponent();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)        //Returning to the menu
        {
            Society_Committee_Member_Menu.menu.showSocietyCommmitteeMemberMenu();
            this.Visibility = Visibility.Collapsed;
        }

        private void Btnsearch_Click(object sender, RoutedEventArgs e)      //For searching the ID and showing the results
        {
            try
            {
                if (txtid.Text == "" || txtid.Text == null)
                {
                    MessageBox.Show("Please Enter ID");
                }
                else
                {
                    if (int.TryParse(txtid.Text,out int id))
                    {
                        Complaint complaint = HSMS_BLL.HSMSBLL.SearchComplaintMemberBLL(id);
                        txbblock.Text = complaint.Block;
                        txbcategory.Text = complaint.Category;
                        txbcomid.Text = complaint.ComplaintId.ToString();
                        txbdate.Text = complaint.Date.ToShortDateString();
                        txbdesc.Text = complaint.Description;
                        txbflatno.Text = complaint.FlatNo.ToString();
                        txbstatus.Text = complaint.Status.ToString();
                        if(complaint.Note=="" || complaint.Note == null)
                        {
                            txbnote.Text = "No Notes Yet";
                        }
                        else
                        {
                            txbnote.Text = complaint.Note;
                        }
                        grddetails.Visibility = Visibility.Visible;
                    }
                    else 
                    {
                        MessageBox.Show("Please Enter ID in valid format");
                    }
                }
                
            }
            catch(Exception)    //If the id is not found
            {
                grddetails.Visibility = Visibility.Hidden;
                MessageBox.Show("No Results for given ID");
            }
        }
    }
}
