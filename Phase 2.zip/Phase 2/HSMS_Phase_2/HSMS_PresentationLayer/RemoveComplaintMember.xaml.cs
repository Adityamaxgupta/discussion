﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Complaint_Entity;
using HSMS_BLL;

namespace HSMS_PresentationLayer
{
    /// <summary>
    /// Interaction logic for RemoveComplaintMember.xaml
    /// </summary>
    public partial class RemoveComplaintMember : UserControl
    {
        int Id;
        public RemoveComplaintMember()
        {
            InitializeComponent();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)        //Return to the previous menu
        {
            Society_Committee_Member_Menu.menu.showSocietyCommmitteeMemberMenu();
            this.Visibility = Visibility.Collapsed;
        }

        private void Btnsearch_Click(object sender, RoutedEventArgs e)      //For searching the complaint to be removed
        {
            try
            {
                if (txtid.Text == "" || txtid.Text == null)
                {
                    MessageBox.Show("Please Enter ID");
                }
                else
                {
                    if (int.TryParse(txtid.Text, out int id))
                    {
                        
                        Complaint complaint = HSMS_BLL.HSMSBLL.SearchComplaintMemberBLL(id);
                        Id = id;
                        txbblock.Text = complaint.Block;
                        txbcategory.Text = complaint.Category;
                        txbcomid.Text = complaint.ComplaintId.ToString();
                        txbdate.Text = complaint.Date.ToShortDateString();
                        txbdesc.Text = complaint.Description;
                        txbflatno.Text = complaint.FlatNo.ToString();
                        txbstatus.Text = complaint.Status.ToString();
                        if (complaint.Note == "" || complaint.Note == null)
                        {
                            txbnote.Text = "No Notes Yet";
                        }
                        else
                        {
                            txbnote.Text = complaint.Note;
                        }
                        grddetails.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        MessageBox.Show("Please Enter ID in valid format");
                    }
                }
                
            }
            catch (Exception)
            {
                grddetails.Visibility = Visibility.Hidden;
                MessageBox.Show("No Results for given ID");
            }
        }

        private void Btnremove_Click(object sender, RoutedEventArgs e)      //For removing the complaint
        {
            if (grddetails.Visibility == Visibility.Visible)
            {
                if (MessageBox.Show("Are you Sure to Delete this?", "Question", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.No) //Prompting to confirm deletion
                {
                    //do no stuff
                }
                else
                {
                    if (HSMSBLL.RemoveComplaintMemberBLL(Id))
                    {
                        MessageBox.Show("Removed Successfully");
                    }
                    else
                    {
                        MessageBox.Show("Could not perform the operation");
                    }
                }
                Society_Committee_Member_Menu.menu.showSocietyCommmitteeMemberMenu();
                this.Visibility = Visibility.Collapsed;
            }
            else
            {
                MessageBox.Show("Please Search First");
            }
        }
    }
}