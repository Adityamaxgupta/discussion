﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Complaint_Entity;
using HSMS_BLL;

namespace HSMS_PresentationLayer
{
    /// <summary>
    /// Interaction logic for RemoveComplaint.xaml
    /// </summary>
    public partial class RemoveComplaint : UserControl
    {
        int Id;
        static string block;
        static int flat;
        public RemoveComplaint(string b, int f)     //Initializing the variables while using
        {
            block = b;
            flat = f;
            InitializeComponent();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)    //Going back to the menu
        {
            Society_Member_Menu.menu.showSocietyMemberMenu();
            this.Visibility = Visibility.Collapsed;
        }

        private void Btnsearch_Click(object sender, RoutedEventArgs e)  //Showing the complaint to be removed
        {
            try
            {
                if (txtid.Text == "" || txtid.Text == null)
                {
                    MessageBox.Show("Please Enter ID");
                }
                else
                {
                    if (int.TryParse(txtid.Text, out int id))
                    {
                        Id = id;
                        Complaint complaint = HSMS_BLL.HSMSBLL.SearchComplaintBLL(id, flat, block);
                        txbblock.Text = complaint.Block;
                        txbcategory.Text = complaint.Category;
                        txbcomid.Text = complaint.ComplaintId.ToString();
                        txbdate.Text = complaint.Date.ToShortDateString();
                        txbdesc.Text = complaint.Description;
                        txbflatno.Text = complaint.FlatNo.ToString();
                        txbstatus.Text = complaint.Status.ToString();
                        if (complaint.Note == "" || complaint.Note == null)
                        {
                            txbnote.Text = "No Notes Yet";
                        }
                        else
                        {
                            txbnote.Text = complaint.Note;
                        }
                        grddetails.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        MessageBox.Show("Please Enter ID in valid format");
                    }
                }
            }
            catch (Exception)
            {
                grddetails.Visibility = Visibility.Hidden;
                MessageBox.Show("No Results for given ID");
            }
        }

        private void Btnremove_Click(object sender, RoutedEventArgs e)  //Actual delete logic
        {
            if (grddetails.Visibility == Visibility.Visible)
            {
                if (MessageBox.Show("Are you Sure to Delete this?", "Question", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.No)    //Prompting to confirm deletion
                {
                    //If no is selected
                    
                }
                else
                {
                    if(HSMSBLL.RemoveComplaintBLL(Id, flat, block))
                    {
                        MessageBox.Show("Removed Succesfully");
                    }
                    else
                    {
                        MessageBox.Show("Could not perform the operation");
                    }
                }
                Society_Member_Menu.menu.showSocietyMemberMenu();
                this.Visibility = Visibility.Collapsed;
            }
            else
            {
                MessageBox.Show("Please Search First");
            }
        }
    }
}
