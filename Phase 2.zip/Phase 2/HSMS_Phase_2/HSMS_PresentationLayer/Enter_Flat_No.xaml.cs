﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HSMS_PresentationLayer
{
    /// <summary>
    /// Interaction logic for Enter_Flat_No.xaml
    /// </summary>
    public partial class Enter_Flat_No : UserControl
    {
        public Enter_Flat_No()      //This page will help to enter block and flat no
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            
            int flatno=0;
            string block = txtbox1.Text;
            bool success = Int32.TryParse(txtbox2.Text, out flatno);
            string s = "Invalid Details\n";
            if(block != "North" && block != "East" && block != "West" && block != "South")
            {
                s = s + "Block Name Invalid or Empty\n It can be North, East, West or South\n";
                success = false;
                txtbox1.Text = "";
            }
            if (flatno < 1 || flatno > 800)
            {
                s = s + "\nFlat no Invalid or Empty\n It can be between 1-800";
                success = false;
                txtbox2.Text = "";
            }
            if (success)
            {
                Society_Member_Menu society = new Society_Member_Menu(flatno,block);
                MainWindow.AppWindow.grdHSMS.Children.Add(society);
                Grid.SetRow(society, 0);
                Grid.SetColumn(society, 0);
                this.Visibility = Visibility.Collapsed;
            }
            else
            {
                MessageBox.Show(s);
            }
        }

    }
}
