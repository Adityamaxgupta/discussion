﻿using Complaint_Entity;
using ComplaintCategory_Entity;
using HSMS_BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HSMS_PresentationLayer
{
    /// <summary>
    /// Interaction logic for ModifyComplaint.xaml
    /// </summary>
    public partial class ModifyComplaint : UserControl
    {
        int Id;
        Complaint complaint;
        static string block;
        static int flat;
        public ModifyComplaint(string b, int f)     //For loading everything, including the combobox from database
        {
            block = b;
            flat = f;
            InitializeComponent();
            List<ComplaintCategory> categeroies = HSMSBLL.GetCategoriesBLL();
            foreach (var item in categeroies)
            {
                cmbcategory.Items.Add(item.Description);
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)        //For returning to the previous menu
        {
            Society_Member_Menu.menu.showSocietyMemberMenu();
            this.Visibility = Visibility.Collapsed;
        }

        private void Btnsearch_Click(object sender, RoutedEventArgs e)      //For searching the item.
        {
            try
            {
                if (txtid.Text == "" || txtid.Text == null)
                {
                    MessageBox.Show("Please Enter ID");
                }
                else
                {
                    if (int.TryParse(txtid.Text, out int id))
                    {
                        Id = id;
                        complaint = HSMS_BLL.HSMSBLL.SearchComplaintBLL(id, flat, block);
                        txbblock.Text = complaint.Block;
                        cmbcategory.Text = complaint.Category;
                        txbcomid.Text = complaint.ComplaintId.ToString();
                        txbdate.Text = complaint.Date.ToShortDateString();
                        txtdesc.Text = complaint.Description.Replace('\n',' ');
                        txbflatno.Text = complaint.FlatNo.ToString();
                        txbstatus.Text = complaint.Status.ToString();
                        if (complaint.Note == "" || complaint.Note == null)
                        {
                            txbnote.Text = "No Notes Yet";
                        }
                        else
                        {
                            txbnote.Text = complaint.Note;
                        }
                        grddetails.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        MessageBox.Show("Please Enter ID in valid format");
                    }
                }                
            }
            catch (Exception)
            {
                grddetails.Visibility = Visibility.Hidden;
                MessageBox.Show("No Results for given ID");
            }
        }

        private void Btnmodify_Click(object sender, RoutedEventArgs e)      //button for actual modification
        {
            if (grddetails.Visibility == Visibility.Visible)
            {
                try
                {
                    string desc = "";
                    int i = 0;
                    foreach (var item in txtdesc.Text.ToCharArray())        //Logic for creating multiline
                    {
                        if (i < 50)
                        {
                            if (item.ToString() != "\n")
                            {
                                desc = desc + item.ToString();
                                i++;
                            }
                            else
                            {
                                desc = desc + item.ToString();
                                i = 0;
                            }
                        }
                        else
                        {
                            if (item.ToString() == "\n" || item.ToString() == " ")
                            {
                                desc = desc + "\n";
                                i = 0;
                            }
                            else
                            {
                                desc = desc + item.ToString();
                                i++;
                            }
                        }

                    }
                    complaint.Description = desc;
                    complaint.Category = cmbcategory.Text;
                    if (HSMSBLL.ModifyComplaintBLL(complaint, flat, block))
                    {
                        MessageBox.Show("Successfully Updated");
                    }
                    else
                    {
                        MessageBox.Show("Could not perform the operation");
                    }
                    Society_Member_Menu.menu.showSocietyMemberMenu();
                    this.Visibility = Visibility.Collapsed;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Updation Failed\n" + ex.Message);
                }
                
            }
            else
            {
                MessageBox.Show("Nothing To Modify");
            }
        }
    }
}