﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Complaint_Entity;
using HSMS_Exception;
using HSMS_DAL;
using System.Text.RegularExpressions;
using ComplaintCategory_Entity;
using ComplaintStatus_Entity;

namespace HSMS_BLL
{
    public class HSMSBLL
    {
        public static bool Validateproperties(Complaint complain)               //This is the function for validating if the complaint is created in a proper format or not
        {
            bool validated = true;
            StringBuilder sb = new StringBuilder();         //This stringbuilder will store all the problems related with the input

            try
            {
                if (complain.Category==null || complain.Category == "")   //It will check whether complain category is valid or not
                {
                    validated = false;
                    sb.Append("\nPlease Select the Category");
                }

                if (complain.Status == null || complain.Status == "")
                {
                    validated = false;
                    sb.Append("\nPlease Select the Status");
                }

                if (complain.Block == null || complain.Block == "")
                {
                    validated = false;
                    sb.Append("\nPlease Enter the Block");
                }

                if (complain.Description == null || complain.Description == "")
                {
                    validated = false;
                    sb.Append("\nPlease Enter the Description");
                }

                if(complain.Block != "North" && complain.Block !="South" && complain.Block!="East" && complain.Block != "West")
                {
                    validated = false;
                    sb.Append("\nBlock can be between North, East, West, South");
                }

                if (complain.FlatNo < 1 || complain.FlatNo > 800)
                {
                    validated = false;
                    sb.Append("\nFlat no cannot be zero or negative or more than 800");
                }

                if (validated == false)
                {
                    throw new HSMSException(sb.ToString());
                }

            }
            catch (HSMSException e)
            {
                throw e;
            }
            catch (Exception e)
            {
                throw e;
            }

            return validated;
        }



        public static bool CreateComplaintBLL(Complaint complaint,out int id)          //Business layer function to create complaint. It will be called from the presentation layer
        {
            bool complaintcreated = false;

            try
            {
                if (Validateproperties(complaint))
                {
                    complaintcreated = HSMSDAL.CreateComplaintDAL(complaint,out id);
                }
                else
                {
                    throw new HSMSException("Please Provide Valid Details");
                }
            }
            catch (HSMSException e)
            {
                throw e;
            }
            catch (Exception e)
            {
                throw e;
            }

            return complaintcreated;
        }



        public static Complaint SearchComplaintBLL(int id, int flatno, string block)       //Business Layer method to search complaint it will work as a mediator between presentation layer and the data access layer
        {
            Complaint complaint = null;

            try
            {
                complaint = HSMSDAL.SearchComplaintDAL(id, flatno, block);
            }
            catch (HSMSException e)
            {
                throw e;
            }
            catch (Exception e)
            {
                throw e;
            }

            return complaint;
        }

        public static Complaint SearchComplaintMemberBLL(int id)       //Business Layer method to search complaint it will work as a mediator between presentation layer and the data access layer
        {
            Complaint complaint = null;

            try
            {
                complaint = HSMSDAL.SearchComplaintMemberDAL(id);
            }
            catch (HSMSException e)
            {
                throw e;
            }
            catch (Exception e)
            {
                throw e;
            }

            return complaint;
        }

        public static bool ModifyComplaintBLL(Complaint complaint, int flatno, string block)      //This business layer function will allow modification of the complaint by the society members
        {
            bool complaintmodified = false;

            try
            {
                if (Validateproperties(complaint))
                {
                    complaintmodified = HSMSDAL.ModifyComplaintDAL(complaint, flatno, block);
                }
                else
                {
                    throw new HSMSException("Please Provide Valid Details");
                }
            }
            catch (HSMSException e)
            {
                throw e;
            }
            catch (Exception e)
            {
                throw e;
            }

            return complaintmodified;
        }



        public static bool RemoveComplaintBLL(int id, int flatno, string block)        //Bussiness layer function to remove the complaints
        {
            bool complaintremoved = false;

            try
            {
                complaintremoved = HSMSDAL.RemoveComplaintDAL(id, flatno, block);
            }
            catch (HSMSException e)
            {
                throw e;
            }
            catch (Exception e)
            {
                throw e;
            }

            return complaintremoved;
        }

        public static bool RemoveComplaintMemberBLL(int id)        //Bussiness layer function to remove the complaints
        {
            bool complaintremoved = false;

            try
            {
                complaintremoved = HSMSDAL.RemoveComplaintMemberDAL(id);
            }
            catch (HSMSException e)
            {
                throw e;
            }
            catch (Exception e)
            {
                throw e;
            }

            return complaintremoved;
        }

        public static List<Complaint> ComplaintsSummaryBLL(int flatno,string block)        //This will return the list of complaints as a summary
        {
            List<Complaint> c = new List<Complaint>();

            try
            {
                c = HSMSDAL.ComplaintsSummaryDAL(flatno,block);
            }
            catch (HSMSException e)
            {
                throw e;
            }
            catch (Exception e)
            {
                throw e;
            }

            return c;
        }

        public static List<Complaint> ComplaintsSummaryMemberBLL()        //This will return the list of complaints as a summary
        {
            List<Complaint> c = new List<Complaint>();

            try
            {
                c = HSMSDAL.ComplaintsSummaryMemberDAL();
            }
            catch (HSMSException e)
            {
                throw e;
            }
            catch (Exception e)
            {
                throw e;
            }

            return c;
        }

        public static bool ModifyComplaintMemberBLL(Complaint complaint)        //This business layer modification method is meant to be used by committee memebr only
        {
            bool modified = false;

            try
            {
                if (Validateproperties(complaint))
                {
                    modified = HSMSDAL.ModifyComplaintMemberDAL(complaint);
                }
                else
                {
                    throw new HSMSException("Please Provide Valid Details");
                }
            }
            catch (HSMSException e)
            {
                throw e;
            }
            catch (Exception e)
            {
                throw e;
            }

            return modified;
        }

        public static List<ComplaintCategory> GetCategoriesBLL()       //To get the Category List
        {
            List<ComplaintCategory> categories = null;

            try
            {
                categories = HSMSDAL.GetCategoriesDLL();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return categories;
        }

        public static List<ComplaintStatus> GetStatusesBLL()       //To get the Status List
        {
            List<ComplaintStatus> statuses = null;

            try
            {
                statuses = HSMSDAL.GetStatusesDLL();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return statuses;
        }

    }
}
