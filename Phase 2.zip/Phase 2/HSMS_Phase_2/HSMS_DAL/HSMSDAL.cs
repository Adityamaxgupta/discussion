﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Complaint_Entity;
using ComplaintCategory_Entity;
using ComplaintStatus_Entity;

namespace HSMS_DAL
{
    public class HSMSDAL
    {
        static SqlConnection conn = new SqlConnection("Data Source=NDAMSSQL\\SQLILEARN;Initial Catalog=Training_13Aug19_Pune;User ID=sqluser;Password=sqluser");  //Connection String
        static SqlCommand cmd;     //Will be used to store and execute command
        static SqlDataReader dr;

        public static bool CreateComplaintDAL(Complaint complaint, out int id)           //This method will store the complaint in the list
        {
            bool complaintcreated = false;

            try
            {
                cmd = new SqlCommand("InsertHSMSComplaint_46003297", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                List<ComplaintCategory> categories = GetCategoriesDLL();
                foreach (var item in categories)
                {
                    if(item.Description== complaint.Category)
                    {
                        cmd.Parameters.AddWithValue("@CategoryId", item.Id);
                    }
                }
                cmd.Parameters.AddWithValue("@Block", complaint.Block);
                cmd.Parameters.AddWithValue("@FlatNo", complaint.FlatNo);
                cmd.Parameters.AddWithValue("@Description", complaint.Description);
                cmd.Parameters.AddWithValue("@Date", complaint.Date);
                conn.Open();
                int result = cmd.ExecuteNonQuery();
                cmd = new SqlCommand("select IDENT_Current('[HSMSComplaint_46003297]')", conn);
                id = Convert.ToInt32(cmd.ExecuteScalar());
                if (result > 0)
                    complaintcreated = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return complaintcreated;
        }



        public static Complaint SearchComplaintDAL(int id, int flatno,string block)               //This method will search the complaint from the list
        {
            Complaint com = null;
            try
            {
                cmd = new SqlCommand("SelectHSMSComplaint_46003297", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", id);
                cmd.Parameters.AddWithValue("@FlatNo", flatno);
                cmd.Parameters.AddWithValue("@Block", block);

                conn.Open();
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    com = new Complaint();
                    com.ComplaintId = dr.GetInt32(0);
                    com.Category = dr.GetString(1);
                    com.Block = dr.GetString(2);
                    com.FlatNo = dr.GetInt32(3);
                    com.Description = dr.GetString(4);
                    com.Date = dr.GetDateTime(5);
                    com.Status = dr.GetString(6);
                    try
                    {
                        com.Note = dr.GetString(7);
                    }
                    catch (Exception)
                    {
                        com.Note = "";
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                dr.Close();
                conn.Close();
            }
            return com;
        }

        public static Complaint SearchComplaintMemberDAL(int id)               //This method will search the complaint from the list
        {
            Complaint com = null;

            try
            {
                cmd = new SqlCommand("SelectHSMSComplaintMember_46003297", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", id);

                conn.Open();
                dr = cmd.ExecuteReader();

                dr.Read();

                com = new Complaint();
                com.ComplaintId = dr.GetInt32(0);
                com.Category = dr.GetString(1);
                com.Block = dr.GetString(2);
                com.FlatNo = dr.GetInt32(3);
                com.Description = dr.GetString(4);
                com.Date = dr.GetDateTime(5);
                com.Status = dr.GetString(6);
                try
                {
                    com.Note = dr.GetString(7);
                }
                catch(Exception)
                {
                    com.Note = "";
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                dr.Close();
                conn.Close();
            }
            return com;
        }

        public static bool ModifyComplaintDAL(Complaint complain, int flatno, string block)           //This method will modify only those complaints which are accessible by the society member
        {
            bool complaintmodified = false;

            try
            {
                cmd = new SqlCommand("UpdateHSMSComplaint_46003297", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", complain.ComplaintId);
                cmd.Parameters.AddWithValue("@block", block);
                cmd.Parameters.AddWithValue("@flatno", flatno);
                List<ComplaintCategory> categories = GetCategoriesDLL();
                foreach (var item in categories)
                {
                    if (item.Description == complain.Category)
                    {
                        cmd.Parameters.AddWithValue("@CategoryID", item.Id);
                    }
                }
                cmd.Parameters.AddWithValue("@Desc", complain.Description);
                conn.Open();
                int result = cmd.ExecuteNonQuery();

                if (result > 0)
                    complaintmodified = true;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conn.Close();
            }
            return complaintmodified;
        }



        public static bool RemoveComplaintDAL(int id, int flatno, string block)                                //It searches the ID and deletes the data having given ID
        {
            bool complaintremoved = false;

            try
            {
                cmd = new SqlCommand("DeleteHSMSComplaint_46003297", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", id);
                cmd.Parameters.AddWithValue("@flatno", flatno);
                cmd.Parameters.AddWithValue("@block", block);

                conn.Open();
                int result = cmd.ExecuteNonQuery();

                if (result > 0)
                    complaintremoved = true;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conn.Close();
            }

            return complaintremoved;
        }

        public static bool RemoveComplaintMemberDAL(int id)                                //It searches the ID and deletes the data having given ID
        {
            bool complaintremoved = false;

            try
            {
                cmd = new SqlCommand("DeleteHSMSComplaintMember_46003297", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", id);

                conn.Open();
                int result = cmd.ExecuteNonQuery();

                if (result > 0)
                    complaintremoved = true;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conn.Close();
            }

            return complaintremoved;
        }

        public static List<Complaint> ComplaintsSummaryDAL(int flatno,string block)                        //It returns all the complaints as a list
        {
            List<Complaint> complaintlist = new List<Complaint>();
            try
            {
                cmd = new SqlCommand("SelectHSMSComplaintsSocietyMember_46003297", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@FlatNo", flatno);
                cmd.Parameters.AddWithValue("@Block", block);
                conn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    complaintlist = new List<Complaint>();

                    while (dr.Read())
                    {
                        Complaint c = new Complaint();
                        c.ComplaintId = dr.GetInt32(0);
                        c.Category = dr.GetString(1);
                        c.Block = dr.GetString(2);
                        c.FlatNo = dr.GetInt32(3);
                        c.Description = dr.GetString(4);
                        c.Date = dr.GetDateTime(5);

                        complaintlist.Add(c);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return complaintlist;
        }

        public static List<Complaint> ComplaintsSummaryMemberDAL()                        //It returns all the complaints as a list
        {
            List<Complaint> complaintlist = new List<Complaint>();

            try
            {
                cmd = new SqlCommand("SelectHSMSComplaintsCommitteeMember_46003297", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                conn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    complaintlist = new List<Complaint>();

                    while (dr.Read())
                    {
                        Complaint c = new Complaint();
                        c.ComplaintId = dr.GetInt32(0);
                        c.Category = dr.GetString(1);
                        c.Block = dr.GetString(2);
                        c.FlatNo = dr.GetInt32(3);
                        c.Description = dr.GetString(4);
                        c.Date = dr.GetDateTime(5);

                        complaintlist.Add(c);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return complaintlist;
        }

        public static bool ModifyComplaintMemberDAL(Complaint complain)             //It modifies the status and note 
        {
            bool complaintmodified = false;

            try
            {
                cmd = new SqlCommand("UpdateHSMSComplaintMember_46003297", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", complain.ComplaintId);
                List<ComplaintStatus> status = GetStatusesDLL();
                foreach (var item in status)
                {
                    if (item.Description == complain.Status)
                    {
                        cmd.Parameters.AddWithValue("@StatusID", item.Id);
                    }
                }
                cmd.Parameters.AddWithValue("@Note", complain.Note);
                conn.Open();
                int result = cmd.ExecuteNonQuery();

                if (result > 0)
                    complaintmodified = true;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conn.Close();
            }

            return complaintmodified;
        }

        public static List<ComplaintCategory> GetCategoriesDLL()       //To get the Category List
        {
            List<ComplaintCategory> categories = null;

            try
            {
                using (SqlConnection sqlConnection = new SqlConnection("Data Source=NDAMSSQL\\SQLILEARN;Initial Catalog=Training_13Aug19_Pune;User ID=sqluser;Password=sqluser"))
                {
                    SqlCommand sqlCmd = new SqlCommand("SELECT * FROM HSMSComplaintCategory_46003297", sqlConnection);
                    sqlConnection.Open();
                    SqlDataReader sqlReader = sqlCmd.ExecuteReader();
                    categories = new List<ComplaintCategory>();
                    while (sqlReader.Read())
                    {
                        ComplaintCategory category = new ComplaintCategory();
                        category.Id = int.Parse(sqlReader["Id"].ToString());
                        category.Description=sqlReader["DESCRIPTION"].ToString();
                        categories.Add(category);
                    }
                    sqlReader.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return categories;
        }

        public static List<ComplaintStatus> GetStatusesDLL()       //To get the Status List
        {
            List<ComplaintStatus> statuses = null;

            try
            {
                using (SqlConnection sqlConnection = new SqlConnection("Data Source=NDAMSSQL\\SQLILEARN;Initial Catalog=Training_13Aug19_Pune;User ID=sqluser;Password=sqluser"))
                {
                    SqlCommand sqlCmd = new SqlCommand("SELECT * FROM HSMSComplaintStatus_46003297", sqlConnection);
                    sqlConnection.Open();
                    SqlDataReader sqlReader = sqlCmd.ExecuteReader();
                    statuses = new List<ComplaintStatus>();
                    while (sqlReader.Read())
                    {
                        ComplaintStatus status = new ComplaintStatus();
                        status.Id = int.Parse(sqlReader["Id"].ToString());
                        status.Description = sqlReader["DESCRIPTION"].ToString();
                        statuses.Add(status);
                    }
                    sqlReader.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return statuses;
        }

    }
}
