﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComplaintCategory_Entity
{
    public class ComplaintCategory      //Template for complaint category
    {
        public int Id { get; set; }
        public string Description { get; set; }
    }
}
