﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Complaint_Entity
{
    public class Complaint  //This is the Template for complaint
    {
        
        private int complaintid;

        public int ComplaintId
        {
            get { return complaintid; }
            set { complaintid = value; }
        }

        private string category;

        public string Category
        {
            get { return category; }
            set { category = value; }
        }

        private string block;

        public string Block
        {
            get { return block; }
            set { block = value; }
        }

        private int flatno;

        public int FlatNo
        {
            get { return flatno; }
            set { flatno = value; }
        }

        private string description;

        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        private DateTime date;

        public DateTime Date
        {
            get { return date; }
            set { date = value; }
        }

        private string status;

        public string Status
        {
            get { return status; }
            set { status = value; }
        }

        private string note;

        public string Note
        {
            get { return note; }
            set { note = value; }
        }

        public Complaint(string category, string block, int flatNo, string description, DateTime date)     //Constructor for object initialization
        {
            Category = category;
            Block = block;
            FlatNo = flatNo;
            Description = description;
            Date = date;
            Status = "Pending";         //This value of status will be set by default when user creates a complain
        }

        public Complaint()
        {

        }

    }
}
