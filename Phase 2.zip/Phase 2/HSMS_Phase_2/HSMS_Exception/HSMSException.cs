﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSMS_Exception
{
    public class HSMSException : ApplicationException
    {
        public HSMSException()
        {
        }

        public HSMSException(string message) : base(message)
        {
        }

        public HSMSException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }
}
