﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComplaintStatus_Entity
{
    public class ComplaintStatus    //This class is a template for complaint status. There is complaint id and the corresponding status
    {
        private int id;

        public int ID
        {
            get { return id; }
            set { id = value; }
        }

        private string description;

        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        public ComplaintStatus(int iD, string description)
        {
            ID = iD;
            Description = description;
        }

    }
}
