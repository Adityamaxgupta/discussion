﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HSMS_BLL;
using HSMS_Exception;
using Complaint_Entity;
using ComplaintStatus_Entity;
using ComplaintCategory_Entity;

namespace HSMS_PresentationLayer
{
    class PresentationLayerPhase1
    {
        static void Main(string[] args)
        {
            int n=0;
            int choice = 0;

            try         
            {
                do
                {
                    PrintMenu();                                    //It will print the outer menu
                    n = int.Parse(Console.ReadLine());
                    switch (n)                                      //Common menu to enter as society member or committee memeber
                    {
                        case 1:
                            Console.Clear();
                            Console.WriteLine("\nEnter your Block:");
                            string block = Console.ReadLine();
                            Console.WriteLine("\nEnter your Flat No:");
                            int flat = int.Parse(Console.ReadLine());
                            if (flat < 1)
                            {
                                Console.Clear();
                                Console.WriteLine("FlatNo Cannot Be Zero or Negative");
                                break;
                            }
                            Console.Clear();
                            do
                            {
                                Console.WriteLine("\n****************Block: " + block + "***************");
                                Console.WriteLine("\n****************Flat No "+flat+"***************");
                                PrintMenu1();                               //Menu for society member
                                choice = int.Parse(Console.ReadLine());
                                Console.Clear();
                                switch (choice)
                                {
                                    case 1:
                                        CreateComplaint(flat,block);
                                        break;
                                    case 2:
                                        SearchComplaint(flat,block);
                                        break;
                                    case 3:
                                        ModifyComplaint(flat,block);
                                        break;
                                    case 4:
                                        Remove(flat,block);
                                        break;
                                    case 5:
                                        ViewSummary(flat,block);
                                        break;
                                    case 6:
                                        Console.Clear();
                                        break;
                                    case 7:
                                        return;
                                    default:
                                        Console.WriteLine("\nPlease Enter a valid choice");
                                        break;
                                }
                            } while (choice!=6);
                            break;
                        case 2:
                            Console.Clear();
                            do
                            {
                                PrintMenu2();                               //Menu for committee member
                                choice = int.Parse(Console.ReadLine());
                                switch (choice)
                                {
                                    case 1:
                                        SearchComplaintMember();
                                        break;
                                    case 2:
                                        ModifyComplaintCom();
                                        break;
                                    case 3:
                                        RemoveMember();
                                        break;
                                    case 4:
                                        ViewSummaryMember();
                                        break;
                                    case 5:
                                        Console.Clear();
                                        break;
                                    case 6:
                                        return;
                                    default:
                                        Console.WriteLine("\nPlease Enter a valid choice");
                                        break;
                                }
                            } while (choice != 5);
                            break;
                        case 3:
                            break;
                        default:
                            Console.WriteLine("\nPlease Enter a Valid Choice");
                            break;
                    }
                } while (n!=3);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Enter Any Key to Exit");
                Console.ReadKey();
            }

        }


        static void PrintMenu()                                                        //Function to print the first menu
        {
            Console.WriteLine("\n*********Choose from the Options********");
            Console.WriteLine("Enter 1 If You Are Society Member");
            Console.WriteLine("Enter 2 If You Are Society Committee Member");
            Console.WriteLine("Enter 3 to Close the Program\n");
        }


        static void PrintMenu1()                                                        //Function to print society member menu
        {
            Console.WriteLine("\n*********Choose from the Options********");
            Console.WriteLine("Enter 1 to Create Complaint");
            Console.WriteLine("Enter 2 to Search Complaint");
            Console.WriteLine("Enter 3 to Modify Complaint");
            Console.WriteLine("Enter 4 to Remove Complaint");
            Console.WriteLine("Enter 5 to View Complaint Summary");
            Console.WriteLine("Enter 6 to Return to the Previous Menu");
            Console.WriteLine("Enter 7 to Quit the Program\n");
        }


        static void PrintMenu2()                                                        //Function to print committee member menu
        {
            Console.WriteLine("\n*********Choose from the Options********");
            Console.WriteLine("Enter 1 to Search Complaint");
            Console.WriteLine("Enter 2 to Modify Complaint");
            Console.WriteLine("Enter 3 to Remove Complaint");
            Console.WriteLine("Enter 4 to View Complaint Summary");
            Console.WriteLine("Enter 5 to Return to Previous Menu");
            Console.WriteLine("Enter 6 to Quit the Program\n");
        }


        static void CreateComplaint(int flatno,string Block)                                                   //Accepts the input and calls business layer create function
        {
            Console.Clear();

            Complaint complaint = null;

            try
            {
                Console.Write("Enter Complaint ID: ");
                string id = Console.ReadLine();
                Console.WriteLine("Enter Complaint Category - Choose Category Number from the Options");
                Console.WriteLine("(1 - Accounting, 2 - Parking, 3 - Electrical, 4 - WaterLeakage, 5 - CCTV)");
                int cat = int.Parse(Console.ReadLine());
                string block = Block;
                int flat = flatno;
                Console.WriteLine("Enter Description: ");
                string desc = Console.ReadLine();
                complaint = new Complaint(id, cat, block, flat, desc, DateTime.Today);

                bool created = HSMSBLL.CreateComplaintBLL(complaint);
                if (created)
                {
                    Console.WriteLine("\nComplaint Created Successfully");
                }
                else
                {
                    throw new HSMSException("\nComplaint Not Created");
                }
            }
            catch (HSMSException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

        }


        static void SearchComplaint(int flatno,string Block)                                            //Accepts the ID and calls the business layer search function
        {
            string id;
            Complaint complaint = null;

            try
            {
                Console.WriteLine("\nEnter the complaint ID to search");
                id = Console.ReadLine();

                complaint = HSMSBLL.SearchComplaintBLL(id,flatno,Block);
                if (complaint != null)
                {
                    Console.WriteLine($"\nComplaint ID: {complaint.ComplaintId} \nCategory: {HSMSBLL.getCategory(complaint.Category)} \nBlock: {complaint.Block} \nFlatNo: {complaint.FlatNo} \nDescription: {complaint.Description} \nDate: {complaint.Date.ToString("dd/MM/yyyy")}");
                    Console.WriteLine($"\nStatus: {HSMSBLL.getStatus(complaint.Status)}");
                    if (complaint.Note != null)
                    {
                        Console.WriteLine($"Note: {complaint.Note}");
                    }
                }
                else
                {
                    throw new HSMSException("\nNo Complaints Against Your Complaint ID");
                }
            }
            catch (HSMSException e)
            {
                Console.WriteLine(e.Message); ;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message); ;
            }
        }

        static void SearchComplaintMember()                                            //Accepts the ID and calls the business layer search function
        {
            string id;
            Complaint complaint = null;

            try
            {
                Console.WriteLine("\nEnter the complaint ID to search");
                id = Console.ReadLine();

                complaint = HSMSBLL.SearchComplaintMemberBLL(id);
                if (complaint != null)
                {
                    Console.WriteLine($"\nComplaint ID: {complaint.ComplaintId} \nCategory: {HSMSBLL.getCategory(complaint.Category)} \nBlock: {complaint.Block} \nFlatNo: {complaint.FlatNo} \nDescription: {complaint.Description} \nDate: {complaint.Date.ToString("dd/MM/yyyy")}");
                    Console.WriteLine($"\nStatus: {HSMSBLL.getStatus(complaint.Status)}");
                    if (complaint.Note != null)
                    {
                        Console.WriteLine($"Note: {complaint.Note}");
                    }
                }
                else
                {
                    throw new HSMSException("\nNo Complaints Against Your Complaint ID");
                }
            }
            catch (HSMSException e)
            {
                Console.WriteLine(e.Message); ;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message); ;
            }
        }

        static void ModifyComplaint(int flatno,string Block)                                               //Accepts the input and calls the business layer modify function
        {
            Complaint complaint = null;
            try
            {
                Console.WriteLine("Enter the ID to Modify: ");
                string id = Console.ReadLine();
                complaint = HSMSBLL.SearchComplaintBLL(id,flatno,Block);
                if (complaint != null)
                {
                    Console.WriteLine("Old Category: "+ HSMSBLL.getCategory(complaint.Category));         //Old values are shown
                    Console.WriteLine("\nEnter y to Change\nEnter n to Skip");      //to check whether user wants to change it
                    string ch = Console.ReadLine();
                    if (ch == "y")
                    {
                        Console.WriteLine("Enter New Category - Choose Category Number from the Options");
                        Console.WriteLine("(1 - Accounting, 2 - Parking, 3 - Electrical, 4 - WaterLeakage, 5 - CCTV)");
                        complaint.Category=int.Parse(Console.ReadLine());
                    }
                    else if (ch != "n")
                    {
                        Console.WriteLine("\nInvalid Input");
                        return;
                    }

                    Console.WriteLine("Old Description: " + complaint.Description);
                    Console.WriteLine("\nEnter y to Change\nEnter n to Skip");
                    ch = Console.ReadLine();
                    if (ch == "y")
                    {
                        Console.WriteLine("Enter New Description:");
                        complaint.Description = Console.ReadLine();
                    }
                    else if (ch != "n")
                    {
                        Console.WriteLine("\nInvalid Input");
                        return;
                    }

                    bool modified = HSMSBLL.ModifyComplaintBLL(complaint,flatno,Block);
                    if(modified)
                    {
                        Console.WriteLine("\nSuccessfully Modified");
                    }
                    else
                    {
                        throw new HSMSException("\nCould Not Modify");
                    }
                }
                else
                {
                    throw new HSMSException("\nNo Complaints Against Your Complaint ID");
                }
            }
            catch (HSMSException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            
        }


        static void ModifyComplaintCom()                                                //Modifies the status and the note 
        {
            Complaint complaint = null;
            try
            {
                Console.WriteLine("Enter the ID to Modify: ");
                string id = Console.ReadLine();
                complaint = HSMSBLL.SearchComplaintMemberBLL(id);
                if (complaint != null)
                {
                    Console.WriteLine($"\nComplaint ID: {complaint.ComplaintId} \nCategory: {complaint.Category} \nBlock: {complaint.Block} \nFlatNo: {complaint.FlatNo} \nDescription: {complaint.Description} \nDate: {complaint.Date.ToString("dd/MM/yyyy")}");

                    Console.WriteLine("\nOld Flat No: " + complaint.FlatNo);
                    Console.WriteLine("\nEnter y to Change\nEnter n to Skip");
                    string ch = Console.ReadLine();
                    if (ch == "y")
                    {
                        Console.WriteLine("Enter New Flat No:");
                        complaint.FlatNo = int.Parse(Console.ReadLine());
                    }
                    else if (ch != "n")
                    {
                        Console.WriteLine("\nInvalid Input");
                        return;
                    }

                    Console.WriteLine("\nOld Status: " + HSMSBLL.getStatus(complaint.Status));
                    Console.WriteLine("\nEnter y to Change\nEnter n to Skip");
                    ch = Console.ReadLine();
                    if (ch == "y")
                    {
                        Console.WriteLine("Enter New Status - Choose from the numbers");
                        Console.WriteLine("1 - Pending, 2 - UnderInvestigation, 3 - Closed)");
                        complaint.Status = int.Parse(Console.ReadLine());
                    }
                    else if (ch != "n")
                    {
                        Console.WriteLine("\nInvalid Input");
                        return;
                    }

                    if (complaint.Note != null)
                    {
                        Console.WriteLine("Old Note: " + complaint.Note);
                    }
                    else
                    {
                        Console.WriteLine("No Note Yet");
                    }
                    Console.WriteLine("\nEnter y to Change\nEnter n to Skip");
                    ch = Console.ReadLine();
                    if (ch == "y")
                    {
                        Console.WriteLine("Enter New Note:");
                        complaint.Note = Console.ReadLine();
                    }
                    else if (ch != "n")
                    {
                        Console.WriteLine("\nInvalid Input");
                        return;
                    }

                    bool modified = HSMSBLL.ModifyComplaintMemberBLL(complaint);
                    if (modified)
                    {
                        Console.WriteLine("\nSuccessfully Modified");
                    }
                    else
                    {
                        throw new HSMSException("\nCould Not Modify");
                    }
                }
                else
                {
                    throw new HSMSException("\nNo Complaints Against Your Complaint ID");
                }
            }
            catch (HSMSException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

        }


        static void Remove(int flatno,string Block)                                                //Accepts the ID and calls delete function of the business layer
        {
            string id;
            try
            {
                Console.WriteLine("Enter ID to Remove");
                id = Console.ReadLine();
                if (HSMSBLL.SearchComplaintBLL(id,flatno,Block) != null)
                {
                    Console.WriteLine("Are you sure to delete?");
                    Console.WriteLine("\nEnter y to Delete\nEnter n to Skip");
                    string ch = Console.ReadLine();
                    if (ch == "y")
                    {
                        bool removed = HSMSBLL.RemoveComplaintBLL(id,flatno,Block);
                        if (removed)
                        {
                            Console.WriteLine("\nRemoval Successful");
                        }
                        else
                        {
                            throw new HSMSException("\nRemoval Failed");
                        }
                    }
                    else if (ch != "n")
                    {
                        Console.WriteLine("\nInvalid Input");
                        return;
                    }
                }
                else
                {
                    throw new HSMSException("\nNo complaint with entered ID");
                }
            }
            catch (HSMSException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        static void RemoveMember()                                                //Accepts the ID and calls delete function of the business layer
        {
            string id;
            try
            {
                Console.WriteLine("Enter ID to Remove");
                id = Console.ReadLine();
                if (HSMSBLL.SearchComplaintMemberBLL(id) != null)
                {
                    Console.WriteLine("Are you sure to delete?");
                    Console.WriteLine("\nEnter y to Delete\nEnter n to Skip");
                    string ch = Console.ReadLine();
                    if (ch == "y")
                    {
                        bool removed = HSMSBLL.RemoveComplaintMemberBLL(id);
                        if (removed)
                        {
                            Console.WriteLine("\nRemoval Successful");
                        }
                        else
                        {
                            throw new HSMSException("\nRemoval Failed");
                        }
                    }
                    else if (ch != "n")
                    {
                        Console.WriteLine("\nInvalid Input");
                        return;
                    }
                }
                else
                {
                    throw new HSMSException("\nNo complaint with entered ID");
                }
            }
            catch (HSMSException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        static void ViewSummary(int flatno,string Block)                                   //Prints all the tables in a tabular format 
        {
            try
            {
                List<Complaint> c = HSMSBLL.ComplaintsSummaryBLL(flatno,Block);
                if (c.Count > 0)
                {
                    Console.WriteLine("--------------------------------------------------------------------------------");
                    Console.WriteLine("Complaint ID \t Category \t Block \tFlatNo\tDescription \t Date");
                    Console.WriteLine("--------------------------------------------------------------------------------");
                    foreach (Complaint comp in c)
                    {
                        Console.WriteLine($"{comp.ComplaintId} \t {HSMSBLL.getCategory(comp.Category)} \t {comp.Block} \t {comp.FlatNo} \t {comp.Description} \t {comp.Date.ToString("dd/MM/yyyy")}");
                    }
                    Console.WriteLine("--------------------------------------------------------------------------------");
                }
                else
                {
                    throw new HSMSException("No Complaints Available");
                }
            }
            catch (HSMSException he)
            {
                Console.WriteLine(he.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        static void ViewSummaryMember()                                   //Prints all the tables in a tabular format 
        {
            try
            {
                List<Complaint> c = HSMSBLL.ComplaintsSummaryMemberBLL();
                if (c.Count > 0)
                {
                    Console.WriteLine("--------------------------------------------------------------------------------");
                    Console.WriteLine("Complaint ID \t Category \t Block \tFlatNo\tDescription \t Date");
                    Console.WriteLine("--------------------------------------------------------------------------------");
                    foreach (Complaint comp in c)
                    {
                        Console.WriteLine($"{comp.ComplaintId} \t {HSMSBLL.getCategory(comp.Category)} \t {comp.Block} \t {comp.FlatNo} \t {comp.Description} \t {comp.Date.ToString("dd/MM/yyyy")}");
                    }
                    Console.WriteLine("--------------------------------------------------------------------------------");
                }
                else
                {
                    throw new HSMSException("No Complaints Available");
                }
            }
            catch (HSMSException he)
            {
                Console.WriteLine(he.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

    }
}
