﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSMS_Exception
{
    public class HSMSException : ApplicationException       //Custom Exception Class
    {
        public HSMSException()                  //Constructor for when exception is thrown without a message
        {
        }

        public HSMSException(string message) : base(message) //Constructor for when exception is thrown with a message
        {
        }

        public HSMSException(string message, Exception innerException) : base(message, innerException)     //Constructor having inner exception
        {
        }
    }
}
