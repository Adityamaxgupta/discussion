﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ComplaintCategory_Entity;
using ComplaintStatus_Entity;
using Complaint_Entity;
using HSMS_Exception;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace HSMS_DAL
{
    public class HSMSDAL
    {
        private static List<Complaint> complaints = new List<Complaint>() ;                              //Actual Data is Stored in these list (Phase 1)
        private static List<ComplaintCategory> complaintCategories = new List<ComplaintCategory>()      //This list is meant to store different complaint categories
        { new ComplaintCategory(1, "Accounting"),new ComplaintCategory(2, "Parking"),new ComplaintCategory(3, "Electrical"),new ComplaintCategory(4, "WaterLeakage"),new ComplaintCategory(5, "CCTV")};     
        private static List<ComplaintStatus> complaintStatuses = new List<ComplaintStatus>()            //This list is meant to store different statuses
        { new ComplaintStatus(1,"Pending"), new ComplaintStatus(2,"UnderInvestigation"), new ComplaintStatus(3,"Closed")};           

        public static string getCategory(int id)         //function for reading category from outside
        {
            ComplaintCategory cat = complaintCategories.Find(c => c.ID == id);
            return cat.Description;
        }

        public static string getStatus(int id)          //function for reading status from outside
        {
            ComplaintStatus stat = complaintStatuses.Find(c => c.ID == id);
            return stat.Description;
        }

        private static bool Serialize()                 //Stores the data in the given file. Will be called from insert update and delete function
        {
            bool serialized = false;
            try
            {
                FileStream fs = new FileStream("HSMS.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter bin = new BinaryFormatter();
                bin.Serialize(fs, complaints);
                serialized = true;
                fs.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                serialized = false;
            }
            return serialized;
        }

        private static List<Complaint> Deserialize()    //Retrieves the data, will be called from search functions
        {
            List<Complaint> descomplaints = new List<Complaint>();
            try
            {
                FileStream fs = new FileStream("HSMS.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                descomplaints = bin.Deserialize(fs) as List<Complaint>;
                fs.Close();
            }
            catch (Exception)
            {
                descomplaints = new List<Complaint>();
            }
            return descomplaints;
        }

        public static bool CreateComplaintDAL(Complaint complaint)           //This method will store the complaint in the list
        {
            bool complaintcreated = false;

            if (complaints.Count == 0)
            {
                complaints = Deserialize();
            }

            try
            {
                complaints.Add(complaint);
                if (Serialize())
                {
                    complaintcreated = true;
                }
                else
                {
                    complaints.Remove(complaint);
                }
            }
            catch (Exception e)
            {
                throw e;
            }

            return complaintcreated;
        }



        public static Complaint SearchComplaintDAL(string id,int flatno,string Block)               //This method will search the complaint from the list
        {
            Complaint com = null;

            if (complaints.Count == 0)
            {
                complaints = Deserialize();
            }

            try
            {
                com = complaints.Find(c => c.ComplaintId == id && c.FlatNo==flatno && c.Block==Block);
            }
            catch (Exception e)
            {
                throw e;
            }

            return com;
        }

        public static Complaint SearchComplaintMemberDAL(string id)               //This method will search the complaint from the list
        {
            Complaint com = null;

            if (complaints.Count == 0)
            {
                complaints = Deserialize();
            }

            try
            {
                com = complaints.Find(c => c.ComplaintId == id);
            }
            catch (Exception e)
            {
                throw e;
            }

            return com;
        }

        public static bool ModifyComplaintDAL(Complaint complain,int flatno,string Block)           //This method will modify only those complaints which are accessible by the society member
        {
            bool complaintmodified = false;

            try
            {
                if (complaints.Count == 0)
                {
                    complaints = Deserialize();
                }
                for (int i = 0; i < complaints.Count; i++)
                {
                    if (complaints[i].ComplaintId == complain.ComplaintId && complaints[i].FlatNo==flatno && complaints[i].Block==Block)
                    {
                        int tempcat = complaints[i].Category;
                        string tempblock = complaints[i].Block;
                        int tempflat = complaints[i].FlatNo;
                        string tempdesc = complaints[i].Description;

                        complaints[i].Category = complain.Category;
                        complaints[i].Block = complain.Block;
                        complaints[i].FlatNo = complain.FlatNo;
                        complaints[i].Description = complain.Description;

                        if (Serialize())
                        {
                            complaintmodified = true;
                        }
                        else
                        {
                            complaints[i].Category = tempcat;
                            complaints[i].Block = tempblock;
                            complaints[i].FlatNo = tempflat;
                            complaints[i].Description = tempdesc;
                        }

                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }

            return complaintmodified;
        }



        public static bool RemoveComplaintDAL(string id,int flatno,string Block)                                //It searches the ID and deletes the data having given ID
        {
            bool complaintremoved = false;

            try
            {
                if (complaints.Count == 0)
                {
                    complaints = Deserialize();
                }
                Complaint complaint = complaints.Find(c => c.ComplaintId == id && c.FlatNo==flatno && c.Block==Block);        //It searches whether the complain actually exist in the list or not

                if (complaint != null)
                {
                    complaints.Remove(complaint);
                    if (Serialize())
                    {
                        complaintremoved = true;
                    }
                    else
                    {
                        complaints.Add(complaint);
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }

            return complaintremoved;
        }

        public static bool RemoveComplaintMemberDAL(string id)                                //It searches the ID and deletes the data having given ID
        {
            bool complaintremoved = false;

            try
            {
                if (complaints.Count == 0)
                {
                    complaints = Deserialize();
                }
                Complaint complaint = complaints.Find(c => c.ComplaintId == id);        //It searches whether the complain actually exist in the list or not

                if (complaint != null)
                {
                    complaints.Remove(complaint);
                    if (Serialize())
                    {
                        complaintremoved = true;
                    }
                    else
                    {
                        complaints.Add(complaint);
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }

            return complaintremoved;
        }

        public static List<Complaint> ComplaintsSummaryDAL(int flatno,string Block)                        //It returns all the complaints as a list
        {
            List<Complaint> complaintlist = new List<Complaint>();
            if (complaints.Count == 0)
            {
                complaints = Deserialize();
            }
            foreach (Complaint item in complaints)
            {
                if (item.FlatNo == flatno && item.Block == Block)
                {
                    complaintlist.Add(item);
                }
            }
            return complaintlist;
        }

        public static List<Complaint> ComplaintsSummaryMemberDAL()                        //It returns all the complaints as a list
        {
            if (complaints.Count == 0)
            {
                complaints = Deserialize();
            }
            return complaints;
        }

        public static bool ModifyComplaintMemberDAL(Complaint complain)             //It modifies the status and note 
        {
            bool complaintmodified = false;

            try
            {
                if (complaints.Count == 0)
                {
                    complaints = Deserialize();
                }
                for (int i = 0; i < complaints.Count; i++)
                {
                    if (complaints[i].ComplaintId == complain.ComplaintId)
                    {
                        int tempflat = complaints[i].FlatNo;
                        string tempnote = complaints[i].Note;
                        int tempstatus = complaints[i].Status;
                        complaints[i].FlatNo = complain.FlatNo;
                        complaints[i].Note = complain.Note;
                        complaints[i].Status = complain.Status;
                        if (Serialize())
                        {
                            complaintmodified = true;
                        }
                        else
                        {
                            complaints[i].FlatNo = tempflat;
                            complaints[i].Note = tempnote;
                            complaints[i].Status = tempstatus;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }

            return complaintmodified;
        }

    }
}
