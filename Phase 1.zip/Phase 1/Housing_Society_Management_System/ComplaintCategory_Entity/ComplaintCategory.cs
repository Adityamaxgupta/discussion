﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComplaintCategory_Entity
{
    public class ComplaintCategory //Using this class the types of complaints will be listed and they can be accessed using an unique number
    {
        private int id;

        public int ID
        {
            get { return id; }
            set { id = value; }
        }

        private string description;

        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        public ComplaintCategory(int iD, string description)
        {
            ID = iD;
            Description = description;
        }
    }
}
