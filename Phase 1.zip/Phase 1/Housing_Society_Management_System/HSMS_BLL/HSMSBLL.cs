﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Complaint_Entity;
using HSMS_Exception;
using HSMS_DAL;
using System.Text.RegularExpressions;

namespace HSMS_BLL
{
    public class HSMSBLL
    {
        public static bool Validateproperties(Complaint complain)               //This is the function for validating if the complaint is created in a proper format or not
        {
            bool validated = true;
            StringBuilder sb = new StringBuilder();         //This stringbuilder will store all the problems related with the input

            try
            {
                if (!Regex.IsMatch(complain.ComplaintId,@"^[A-Z]{2}-[0-9]{4}$"))        //Here it will check if the complaint id is in valid format or not
                {
                    validated = false;
                    sb.Append("Invalid Complaint ID\nIt should contain 2 capital letters then a hyphen followed by 4 digits\n");
                }

                if (complain.Category<1 || complain.Category>5)   //It will check whether complain category is valid or not
                {
                    validated = false;
                    sb.Append("Invalid Category\nIt should be between (1 - Accounting, 2 - Parking, 3 - Electrical, 4 - WaterLeakage, 5 - CCTV)\n");
                }

                if (complain.Status<1 || complain.Status > 3)
                {
                    validated = false;
                    sb.Append("Invalid Status\nIt should be between (1 - Pending, 2 - UnderInvestigation, 3 - Closed)\n");
                }
                
                if (complain.FlatNo < 1)
                {
                    validated = false;
                    sb.Append("\nFlat no cannot be zero or negative");
                }

                if (validated == false)
                {
                    throw new HSMSException(sb.ToString());
                }

            }
            catch (HSMSException e)
            {
                throw e;
            }
            catch (Exception e)
            {
                throw e;
            }

            return validated;
        }



        public static bool CreateComplaintBLL(Complaint complaint)          //Business layer function to create complaint. It will be called from the presentation layer
        {
            bool complaintcreated = false;

            try
            {
                if (Validateproperties(complaint))
                {
                    if (HSMSDAL.SearchComplaintMemberDAL(complaint.ComplaintId) == null)      //Checks if the provided ID already exists or not
                    {
                        complaintcreated = HSMSDAL.CreateComplaintDAL(complaint);
                    }
                    else
                    {
                        throw new HSMSException("Given Complaint ID already exists");
                    }
                }
                else
                {
                    throw new HSMSException("Please Provide Valid Details");
                }
            }
            catch (HSMSException e)
            {
                throw e;
            }
            catch (Exception e)
            {
                throw e;
            }

            return complaintcreated;
        }


        
        public static Complaint SearchComplaintBLL(string id,int flatno,string Block)       //Business Layer method to search complaint it will work as a mediator between presentation layer and the data access layer
        {
            Complaint complaint = null;

            try
            {
                if (Regex.IsMatch(id, @"^[A-Z]{2}-[0-9]{4}$"))      //This regex checks if the enteret id for searching is given in a valid format or not
                {
                    complaint = HSMSDAL.SearchComplaintDAL(id,flatno,Block);
                }
                else
                {
                    throw new HSMSException("Please provide a search id in valid format");
                }
            }
            catch (HSMSException e)
            {
                throw e;
            }
            catch (Exception e)
            {
                throw e;
            }

            return complaint;
        }

        public static Complaint SearchComplaintMemberBLL(string id)       //Business Layer method to search complaint it will work as a mediator between presentation layer and the data access layer
        {
            Complaint complaint = null;

            try
            {
                if (Regex.IsMatch(id, @"^[A-Z]{2}-[0-9]{4}$"))      //This regex checks if the enteret id for searching is given in a valid format or not
                {
                    complaint = HSMSDAL.SearchComplaintMemberDAL(id);
                }
                else
                {
                    throw new HSMSException("Please provide a search id in valid format");
                }
            }
            catch (HSMSException e)
            {
                throw e;
            }
            catch (Exception e)
            {
                throw e;
            }

            return complaint;
        }

        public static bool ModifyComplaintBLL(Complaint complaint,int flatno,string Block)      //This business layer function will allow modification of the complaint by the society members
        {
            bool complaintmodified = false;

            try
            {
                if (Validateproperties(complaint))
                {
                    complaintmodified = HSMSDAL.ModifyComplaintDAL(complaint,flatno,Block);
                }
                else
                {
                    throw new HSMSException("Please Provide Valid Details");
                }
            }
            catch (HSMSException e)
            {
                throw e;
            }
            catch (Exception e)
            {
                throw e;
            }

            return complaintmodified;
        }



        public static bool RemoveComplaintBLL(string id,int flatno,string Block)        //Bussiness layer function to remove the complaints
        {
            bool complaintremoved = false;

            try
            {
                if (Regex.IsMatch(id, @"^[A-Z]{2}-[0-9]{4}$"))
                {
                    complaintremoved = HSMSDAL.RemoveComplaintDAL(id,flatno,Block);
                }
                else
                {
                    throw new HSMSException("Please provide a search id in valid format");
                }
            }
            catch (HSMSException e)
            {
                throw e;
            }
            catch (Exception e)
            {
                throw e;
            }

            return complaintremoved;
        }

        public static bool RemoveComplaintMemberBLL(string id)        //Bussiness layer function to remove the complaints
        {
            bool complaintremoved = false;

            try
            {
                if (Regex.IsMatch(id, @"^[A-Z]{2}-[0-9]{4}$"))
                {
                    complaintremoved = HSMSDAL.RemoveComplaintMemberDAL(id);
                }
                else
                {
                    throw new HSMSException("Please provide a search id in valid format");
                }
            }
            catch (HSMSException e)
            {
                throw e;
            }
            catch (Exception e)
            {
                throw e;
            }

            return complaintremoved;
        }

        public static List<Complaint> ComplaintsSummaryBLL(int flatno,string Block)        //This will return the list of complaints as a summary
        {
            List<Complaint> c = new List<Complaint>();

            try
            {
                c = HSMSDAL.ComplaintsSummaryDAL(flatno,Block);
            }
            catch (HSMSException e)
            {
                throw e;
            }
            catch (Exception e)
            {
                throw e;
            }

            return c;
        }

        public static List<Complaint> ComplaintsSummaryMemberBLL()        //This will return the list of complaints as a summary
        {
            List<Complaint> c = new List<Complaint>();

            try
            {
                c = HSMSDAL.ComplaintsSummaryMemberDAL();
            }
            catch (HSMSException e)
            {
                throw e;
            }
            catch (Exception e)
            {
                throw e;
            }

            return c;
        }

        public static bool ModifyComplaintMemberBLL(Complaint complaint)        //This business layer modification method is meant to be used by committee memebr only
        {
            bool modified = false;

            try
            {
                if (Validateproperties(complaint))
                {
                    modified = HSMSDAL.ModifyComplaintMemberDAL(complaint);
                }
                else
                {
                    throw new HSMSException("Please Provide Valid Details");
                }
            }
            catch (HSMSException e)
            {
                throw e;
            }
            catch (Exception e)
            {
                throw e;
            }

            return modified;
        }

        public static string getCategory(int id)
        {
            return HSMSDAL.getCategory(id);
        }

        public static string getStatus(int id)
        {
            return HSMSDAL.getStatus(id);
        }

    }
}
