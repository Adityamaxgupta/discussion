﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Complaint_Entity
{
    [Serializable]
    public class Complaint      //This is the entity Class. Each complaint will be having the following properties
    {
        private string complaintid;

        public string ComplaintId
        {
            get { return complaintid; }
            set { complaintid = value; }
        }

        private int category;

        public int Category
        {
            get { return category; }
            set { category = value; }
        }

        private string block;

        public string Block
        {
            get { return block; }
            set { block = value; }
        }

        private int flatno;

        public int FlatNo
        {
            get { return flatno; }
            set { flatno = value; }
        }

        private string description;

        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        private DateTime date;

        public DateTime Date
        {
            get { return date; }
            set { date = value; }
        }

        private int status;

        public int Status
        {
            get { return status; }
            set { status = value; }
        }

        private string note;

        public string Note
        {
            get { return note; }
            set { note = value; }
        }

        public Complaint(string complaintId, int category, string block, int flatNo, string description, DateTime date)     //Constructor for object initialization
        {
            ComplaintId = complaintId;
            Category = category;
            Block = block;
            FlatNo = flatNo;
            Description = description;
            Date = date;
            Status = 1;         //This value of status will be set by default when user creates a complain
        }

    }
}
